package org.clover.resource;

public class Resource {
}
